import pymongo

class DataBase():
    def __init__(self):
        self._client = pymongo.MongoClient('mongodb://localhost:27017/')
        self._db_users = self._client['users']
        self._db_ps = self._client['PS']

    def register_user(self, user_info):
        # Obtener la colección de usuarios (equivalente a una tabla en MongoDB)
        usuarios_collection = self._db_users['usuarios']

        # Insertar datos desde el diccionario
        usuarios_collection.insert_one(user_info)
        return True

    def find_user(self, ID, password):
        # Obtener la colección de usuarios
        usuarios_collection = self._db_users['usuarios']

        # Consulta para verificar la existencia del usuario
        query = {'Mail': ID, 'Password': password}
        user = usuarios_collection.find_one(query)

        # Devolver True si se encuentra el usuario, False en caso contrario
        return user is not None

    def find_ps(self, ID, password):
        # Obtener la colección de PS
        ps_collection = self._db_ps['PS']

        # Consulta para verificar la existencia del usuario en la colección PS
        query = {'Mail': ID, 'Password': password}
        user = ps_collection.find_one(query)

        # Devolver True si se encuentra el usuario, False en caso contrario
        return user is not None
    
    def user_exists(self, ID):
        # Verificar si el usuario existe en la colección de usuarios
        usuarios_collection = self._db_users['usuarios']
        query = {'Mail': ID}
        user = usuarios_collection.find_one(query)

        # Devolver True si el usuario existe, False en caso contrario
        return user is not None
    
    def get_user_info(self, ID):
        # Obtener la colección de usuarios
        usuarios_collection = self._db_users['usuarios']

        # Consulta para obtener la información del usuario
        query = {'Mail': ID}
        user_info = usuarios_collection.find_one(query)

        # Devolver la información del usuario si se encuentra, None en caso contrario
        return user_info
