import re
from flask import Flask, render_template,request,redirect,url_for,flash,session
from DataBase import DataBase

app = Flask(__name__)
DB = DataBase()

def validate_email(email):
    boolean= DB.user_exists(email)
    return boolean

def validate_size(size):
    valid_sizes = ['xs', 's', 'm', 'l', 'xl', '2xl']
    return size.lower() in valid_sizes

def validate_shoe(size):
    valid_sizes = list(range(36, 51))
    return size in valid_sizes

def validate_password(password):
    # Mínimo una mayúscula, un número y longitud mínima de 8 caracteres
    return re.search(r'^(?=.*[A-Z])(?=.*\d).{8,}$', password) is not None

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/singin', methods=['GET', 'POST'])
def singin():
    if request.method == 'POST':
        mail = request.form['mail']
        password = request.form['password']
        user_type = request.form['type']
        if mail=='admin' and password=='admin':
            return redirect(url_for('ps_template')) 
        if user_type == 'PS':
            boolean = DB.find_ps(mail, password)
        elif user_type == 'User':
            boolean = DB.find_user(mail, password)   
        if boolean:
            session['user_mail']=mail
            if user_type == 'PS':
                return redirect(url_for('ps_template'))  # Redirige a la plantilla de Personal Shopper
            elif user_type == 'User':
                return redirect(url_for('user_template'))  # Redirige a la plantilla de Usuario
        else:
            # Muestra una notificación de error
            flash('error')
            return redirect(url_for('singin'))

    return render_template("singin.html")


@app.route('/registration', methods=['GET', 'POST'])
def registration():
    if request.method == 'POST':
        # Verificar campos vacíos
        required_fields = ['ID', 'mail', 'birthday', 'password', 'jacket', 'shirt', 'bottom', 'shoe', 'tastes', 'preferences']
        for field in required_fields:
            if not request.form.get(field):
                flash('required')
                return redirect(url_for('registration'))

        # Recopilar la información del formulario
        user_info = {
            'ID': request.form['ID'],
            'Mail': request.form['mail'],
            'Birthday': request.form['birthday'],
            'Password': request.form['password'],
            'jacket': request.form['jacket'],
            'shirt': request.form['shirt'],
            'bottom': request.form['bottom'],
            'shoe': int(request.form['shoe']),
            'tastes': request.form['tastes'],
            'preferences': request.form['preferences'],
            'clothes': []
        }

        if validate_email(user_info['Mail'])==True:
            flash('User')
            return redirect(url_for('singin'))

        if not validate_password(user_info['Password']):
            flash('pwd')
            return redirect(url_for('registration'))

        if  not validate_size(user_info['jacket']):
            flash('size')
            return redirect(url_for('registration'))

        if  not validate_size(user_info['shirt']):
            flash('size')
            return redirect(url_for('registration'))

        if  not validate_size(user_info['bottom']):
            flash('size')
            return redirect(url_for('registration'))

        if not validate_shoe(user_info['shoe']):
            flash('shoe')
            return redirect(url_for('registration'))

        # Registrar el usuario en la base de datos
        DB.register_user(user_info)
        session['user_mail']=user_info['Mail']
        flash('Register Completed!')
        return redirect(url_for("user_template"))
    return render_template("registration.html")

@app.route('/user_template')
def user_template():
    return render_template('user_template.html')

@app.route('/ps_template')
def ps_template():
    return render_template('ps_template.html')

@app.route('/chat')
def chat():
     return render_template('chat.html')

@app.route('/asesoria',methods=['GET', 'POST'])
def asesoria():
      if request.method == 'POST':
        user=session['user_mail']
        DB.SelectPS(user)
        Productos_User = DB.get_clothes(user)
        if Productos_User!=None:
            return render_template('asesoria.html',producsts=Productos_User)
        else:
           return render_template('asesoria.html',producsts=[])
      else:
        user=session['user_mail']
        Productos_User = DB.get_clothes(user)
        if Productos_User!=None:
            return render_template('asesoria.html',producsts=Productos_User)
        else:
           return render_template('asesoria.html',producsts=[])

@app.route('/aboutus')
def aboutus():
     return render_template('aboutus.html')

@app.route('/profile')
def profile():
     user=session['user_mail']
     user_info=DB.get_user_info(user)
     return render_template('profile.html',name=user_info['ID'],Mail=user_info['Mail'],Birthday=user_info['Birthday'],jacket=user_info['jacket'],shirt=user_info['shirt'],bottom=user_info['bottom'],shoe=user_info['shoe'],tastes=user_info['tastes'],preferences=user_info['preferences'])

@app.route('/PsUsers')
def PsUsers():
     user=session['user_mail']
     Usuaris=DB.get_ps_user(user)
     return render_template('PsUsers.html',Users=Usuaris)

@app.route('/products',methods=['GET', 'POST'])
def products():
     if request.method == 'POST':
        product_param = request.form.get('filtro')
        brand_param = request.form.get('Marca')
        mail_user=request.form.get('Mail')
        item_user=request.form.get('Item')
        Marca_user=request.form.get('PMarca')
        DB.Add_Item(mail_user,item_user,Marca_user)
        filtered_products = DB.get_product(product=product_param, brand=brand_param)
        return render_template('products.html', products=filtered_products)
     else:
        return render_template('products.html', products=[]) 


if __name__ == '__main__':
    app.secret_key="1111"
    app.run(debug=True)