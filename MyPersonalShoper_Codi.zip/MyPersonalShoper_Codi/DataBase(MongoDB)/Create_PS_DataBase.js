// Crear la base de datos "PS"
use ps

// Crear la colección "usuarios" y agregar algunos documentos de ejemplo
db.ps.insertMany([
  {
    Name: "Josep",
    Mail: "josep@gmail.com",
    Password: "Name2003",
    Users:[]
  },
  {
    Name: "Mar",
    Mail: "mar@gmail.com",
    Password: "Name2003",
    Users:[]
  },
  {
    Name: "Laura",
    Mail: "Laura@gmail.com",
    Password: "Name2003",
    Users:[]
  },
  {
    Name: "Alex",
    Mail: "Alex@gmail.com",
    Password: "Name2003",
    Users:[]
  }
])

// Mostrar los documentos en la colección
db.ps.find().pretty()
