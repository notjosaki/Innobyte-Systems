// Crear la base de datos "PS"
use Products

// Crear la colección "usuarios" y agregar algunos documentos de ejemplo
db.Products.insertMany([
  {
    product: "Pant",
    barnd: "Puma",
    size:["s","xl"]
  },
  {
    product: "Shirt",
    barnd: "Salomone",
    size:["m"]
  },
  {
    product: "Pant",
    barnd: "Rick",
    size:["xs"]
  },
  {
    product: "Pant",
    barnd: "Nike",
    size:["s","l"]
  }
])

// Mostrar los documentos en la colección
db.Products.find().pretty()