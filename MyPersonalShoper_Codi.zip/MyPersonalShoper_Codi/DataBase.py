import pymongo

class DataBase():
    def __init__(self):
        self._client = pymongo.MongoClient('mongodb://localhost:27017/')
        self._db_users = self._client['users']
        self._db_ps = self._client['ps']
        self._db_productos= self._client['Products']

    def register_user(self, user_info):

        usuarios_collection = self._db_users['users']

        usuarios_collection.insert_one(user_info)
        return True

    def find_user(self, ID, password):

        usuarios_collection = self._db_users['users']


        query = {'Mail': ID, 'Password': password}
        user = usuarios_collection.find_one(query)


        return user is not None

    def find_ps(self, ID, password):

        ps_collection = self._db_ps['ps']
        query = {'Mail': ID, 'Password': password}
        user = ps_collection.find_one(query)


        return user is not None
    
    def user_exists(self, ID):

        usuarios_collection = self._db_users['users']
        query = {'Mail': ID}
        user = usuarios_collection.find_one(query)
        return user is not None
    
    def get_user_info(self, ID):

        usuarios_collection = self._db_users['users']
        query = {'Mail': ID}
        user_info = usuarios_collection.find_one(query)

        # Devolver la información del usuario si se encuentra, None en caso contrario
        return user_info

    def get_ps_user(self,ID):
        ps_collection = self._db_ps['ps']


        ps_query = {'Mail': ID}
        ps_document = ps_collection.find_one(ps_query)

      
        if ps_document:
            users_array = ps_document.get('Users', [])

            return users_array


        return None
    
    def get_product(self,product=None,brand=None):
        Products_collection = self._db_productos['Products']
        query = {}
        if product:
            query['product'] = product
        if brand:
            query['brand'] = brand

        result = Products_collection.find(query)
        print(result)
        return list(result)
    
    def get_clothes(self,user):
        usuarios_collection = self._db_users['users']
        query = {'Mail': user}
        user_info = usuarios_collection.find_one(query)

    
        if user_info:         
            clothes_info = user_info.get('clothes', None)
            return clothes_info


        return None
    
    def Add_Item(self,mail,item,brand):
            usuarios_collection = self._db_users['users']
            user_query = {'Mail': mail}
            user = usuarios_collection.find_one(user_query)

       
            if user:
                if 'clothes' in user:
                    
                    user['clothes'].append({'item': item, 'brand': brand})
                else:

                    user['clothes'] = [{'item': item, 'brand': brand}]
    
                usuarios_collection.update_one(user_query, {'$set': user})

    def SelectPS(self, user):
        ps_collection = self._db_ps['ps']
        all_ps = ps_collection.find().sort("Name")

        ps_user_counts = {}

        for ps in all_ps:
            ps_name = ps.get('Name')
            users_count = ps_user_counts.get(ps_name, 0)
            
            users_count = len(ps.get('Users', []))  # Corregir aquí

            ps_user_counts[ps_name] = users_count

        selected_ps_name = min(ps_user_counts, key=ps_user_counts.get)

        usuarios_collection = self._db_users['users']
        query = {'Mail': user}
        user_info = usuarios_collection.find_one(query)
        
        ps_collection.update_one({'Name': selected_ps_name}, {'$push': {
            'Users': {
                'mail': user_info.get('Mail', ''),
                'name': user_info.get('ID', ''),
                'size':[ user_info.get('jacket', ''),user_info.get('shirt', ''),user_info.get('bottom', ''),user_info.get('shoe', '')],  
                'tastes': user_info.get('tastes', ''),
                'preferences': user_info.get('preferences', ''),
            }
        }})

        return selected_ps_name
    
       
    
       
       